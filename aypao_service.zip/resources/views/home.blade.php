@extends('layouts.master')
@section('titel', 'HOME')

@section('content')
    <div class="d-flex justify-content-center mt-2">
        <img src="img/logo_aypao.jpg" class="img-fluid">
    </div>

@endsection
