<?php $__env->startSection('titel', 'HOME'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center mt-2">
        <img src="img/logo_aypao.jpg" class="img-fluid">
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aypao_service\resources\views/home.blade.php ENDPATH**/ ?>