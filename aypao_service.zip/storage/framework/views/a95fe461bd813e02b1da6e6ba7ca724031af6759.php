<?php $__env->startSection('title', 'CCTV'); ?>
<?php $__env->startSection('content'); ?>


    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('cctv')); ?>">Cctv</a></li>

        </ol>
    </nav>

    <div class="container">
        <div class="card ">
            <div class="card-header bg-aypao-header">
                <h5>บันทึกการขอดูข้อมูล CCTV</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo e(route('cctv_add')); ?>" class="btn btn-outline-secondary">เพิ่มข้อมูล</a>
                    </div>
                </div>
                <div class="row">
                    <table class="table ">
                        <thead class="bg-aypao-header-sub">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">First</th>
                                <th scope="col">Last</th>
                                <th scope="col">Handle</th>
                                <th scope="col">Handle</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $cctv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($i); ?></td>
                                    <td><?php echo e($row->cus_fname); ?></td>

                                    <td><?php echo e($row->cus_lname); ?></td>

                                    <td><?php echo e($row->cctv_event_info); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('cctv_edit', ['id' => $row->id])); ?>"
                                            class="btn btn-primary">แก้ไขข้อมูล</a>
                                    </td>

                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($cctv->links()); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aypao_service\resources\views/cctv/index.blade.php ENDPATH**/ ?>